// Interfaz Observer que define el método notify
public interface Observer {
    void notify(Book book);
}