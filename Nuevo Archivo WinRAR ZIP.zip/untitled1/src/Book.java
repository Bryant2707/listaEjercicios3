// Clase Libro
public class Book {
    private String title;
    private String author;
    private int publicationYear;
    private String genre;
    private int numberOfPages;
    private String loanStatus; // OCUPADO, LIBRE, NO EXISTE
    private int numberOfChapters;
    private String releaseDate; // Fecha de liberación si está ocupado

    // Constructor privado
    private Book(Builder builder) {
        this.title = builder.title;
        this.author = builder.author;
        this.publicationYear = builder.publicationYear;
        this.genre = builder.genre;
        this.numberOfPages = builder.numberOfPages;
        this.loanStatus = builder.loanStatus;
        this.numberOfChapters = builder.numberOfChapters;
        this.releaseDate = builder.releaseDate;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public String getGenre() {
        return genre;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public String getLoanStatus() {
        return loanStatus;
    }

    public int getNumberOfChapters() {
        return numberOfChapters;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    // Setters
    public void setLoanStatus(String loanStatus) {
        this.loanStatus = loanStatus;
    }

    // Builder para la clase Libro
    public static class Builder {
        private String title;
        private String author;
        private int publicationYear;
        private String genre;
        private int numberOfPages;
        private String loanStatus; // OCUPADO, LIBRE, NO EXISTE
        private int numberOfChapters;
        private String releaseDate; // Fecha de liberación si está ocupado

        public Builder(String title, String author) {
            this.title = title;
            this.author = author;
        }

        public Builder publicationYear(int publicationYear) {
            this.publicationYear = publicationYear;
            return this;
        }

        public Builder genre(String genre) {
            this.genre = genre;
            return this;
        }

        public Builder numberOfPages(int numberOfPages) {
            this.numberOfPages = numberOfPages;
            return this;
        }

        public Builder loanStatus(String loanStatus) {
            this.loanStatus = loanStatus;
            return this;
        }

        public Builder numberOfChapters(int numberOfChapters) {
            this.numberOfChapters = numberOfChapters;
            return this;
        }

        public Builder releaseDate(String releaseDate) {
            this.releaseDate = releaseDate;
            return this;
        }

        public Book build() {
            return new Book(this);
        }
    }
}
