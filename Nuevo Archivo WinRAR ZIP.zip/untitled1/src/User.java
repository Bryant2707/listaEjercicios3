import java.util.ArrayList;
import java.util.List;

// Clase Usuario que implementa el patrón Observer
public class User implements Observer {
    private String name;
    private List<Book> favoriteBooks = new ArrayList<>();

    public User(String name) {
        this.name = name;
    }

    @Override
    public void notify(Book book) {
        System.out.println("Hola " + name + ", el libro " + book.getTitle() + " ahora está disponible.");
    }

    public void addFavoriteBook(Book book) {
        favoriteBooks.add(book);
    }

    // Método para obtener el nombre del usuario
    public String getName() {
        return name;
    }
}
