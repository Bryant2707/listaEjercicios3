import java.util.ArrayList;
import java.util.List;

// Clase LibroRepository que gestiona la colección de libros
public class BookRepository {
    private List<Book> books = new ArrayList<>();
    private BookNotifier notifier = new BookNotifier();

    // Método para agregar un libro
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Libro añadido: " + book.getTitle());
    }

    // Método para suscribir un usuario a un libro
    public void subscribeUser(User user, Book book) {
        user.addFavoriteBook(book);
        notifier.subscribe(user);
        System.out.println("Usuario " + user.getName() + " suscrito a " + book.getTitle());
    }

    // Método para actualizar la disponibilidad de un libro
    public void updateBookAvailability(Book book, boolean isAvailable) {
        book.setLoanStatus(isAvailable ? "FREE" : "OCCUPIED");
        if (isAvailable) {
            notifier.notifyAll(book);
        }
    }

    // Método para buscar libros por autor
    public List<Book> searchByAuthor(String author) {
        List<Book> results = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                results.add(book);
            }
        }
        return results;
    }

    // Método para buscar libros por género
    public List<Book> searchByGenre(String genre) {
        List<Book> results = new ArrayList<>();
        for (Book book : books) {
            if (book.getGenre().equalsIgnoreCase(genre)) {
                results.add(book);
            }
        }
        return results;
    }
}
