import java.util.ArrayList;
import java.util.List;

// Clase BookNotifier que gestiona las notificaciones
public class BookNotifier {
    private List<Observer> observers = new ArrayList<>();

    public void subscribe(Observer observer) {
        observers.add(observer);
    }

    public void notifyAll(Book book) {
        for (Observer observer : observers) {
            observer.notify(book);
        }
    }
}
