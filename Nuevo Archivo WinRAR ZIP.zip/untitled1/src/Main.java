// Clase Main para ejecutar el sistema
public class Main {
    public static void main(String[] args) {
        // Crear instancia del repositorio de libros
        BookRepository repository = new BookRepository();

        // Crear algunos libros
        Book book1 = new Book.Builder("1984", "George Orwell")
                .publicationYear(1949)
                .genre("Dystopian")
                .numberOfPages(328)
                .loanStatus("FREE")
                .numberOfChapters(24)
                .build();

        Book book2 = new Book.Builder("To Kill a Mockingbird", "Harper Lee")
                .publicationYear(1960)
                .genre("Fiction")
                .numberOfPages(281)
                .loanStatus("OCCUPIED")
                .numberOfChapters(31)
                .releaseDate("2024-01-01")
                .build();

        // Añadir libros al repositorio
        repository.addBook(book1);
        repository.addBook(book2);

        // Crear usuario
        User user1 = new User("Juan");

        // Suscribir usuario al libro
        repository.subscribeUser(user1, book2);

        // Cambiar disponibilidad del libro
        repository.updateBookAvailability(book2, true);
    }
}
